-- Questao 3 b

f g(x y) x y = z