-- Questao 1:

a -> b -> c -> (a->c) -> (b->c)