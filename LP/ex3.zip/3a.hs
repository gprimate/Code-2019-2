-- Questao 3 a

f (x <= x) x = String