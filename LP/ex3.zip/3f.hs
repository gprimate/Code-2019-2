-- Questao 3 f

f [(x,y)] = ([x], [y])