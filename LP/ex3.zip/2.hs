-- Questão 2

(a,b) -> a -> b