-- Questao 3 e

f g(y) h(x) x = z