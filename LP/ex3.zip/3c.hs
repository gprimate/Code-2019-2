-- Questao 3 c

f (g, h) x = (y,z)